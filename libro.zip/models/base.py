#Base class to define a base instance 
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()