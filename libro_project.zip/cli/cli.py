import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import fire
from sqlalchemy.orm import sessionmaker
#from sqlalchemy import create_engine
from models.base import Base
from models.borrow import borrow_book, return_book
from models.library import Library
from models.member import Member
from models.book import Book
from main import engine  # Importing the engine from main.py for the database connection



Session = sessionmaker(bind=engine)
session = Session()

def borrow(member_name, library_name, book_title):
    result = borrow_book(member_name,library_name, book_title, session)
    return result

def return_a_book(member_name,book_title):
    result = return_book(member_name,book_title,session)
    return result

if __name__ == "__main__":
    fire.Fire({"borrow":borrow,"return_book":return_a_book})