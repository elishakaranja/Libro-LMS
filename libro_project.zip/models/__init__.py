#models/ folder must have an __init__.py file, even if it’s empty.
#This tells Python to treat models/ as a package so main.py can import models.